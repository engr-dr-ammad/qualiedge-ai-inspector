# Known issues / limitations

- Milestone 1 is a shell; navigation pages beyond Dashboard are explicitly placeholders.
- GUI tests and PyInstaller build require dependencies unavailable in the current authoring environment.
- Windows installer paths and build workflow need Windows runner verification.
- No `.qerecipe` file association yet; add when recipe import/export exists.
- Icons, full translations and third-party licence bundle remain pending.
