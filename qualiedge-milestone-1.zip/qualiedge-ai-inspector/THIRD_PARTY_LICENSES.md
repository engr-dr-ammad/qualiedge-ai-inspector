# Preliminary dependency licence inventory

Verify the exact versions and bundled transitive dependencies before distribution.

- Python: PSF Licence
- PySide6 / Qt: LGPLv3/GPL/commercial options; comply with LGPL obligations for the selected distribution
- platformdirs: MIT
- Pydantic: MIT
- pytest: MIT
- pytest-qt: MIT
- Ruff: MIT
- mypy: MIT
- PyInstaller: GPL-2.0-or-later with bootloader exception (check complete terms)
- Inno Setup: Inno Setup licence (check redistribution requirements)

This is **not** yet a complete third-party licence bundle.
