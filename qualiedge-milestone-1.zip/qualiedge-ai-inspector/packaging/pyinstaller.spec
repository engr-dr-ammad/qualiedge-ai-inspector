# Run from repository root: pyinstaller --noconfirm packaging/pyinstaller.spec
from PyInstaller.utils.hooks import collect_data_files

a = Analysis(
    ['src/qualiedge/__main__.py'],
    pathex=['src'],
    binaries=[],
    datas=collect_data_files('platformdirs'),
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='QualiEdge-Inspector',
          debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
          console=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False,
               name='QualiEdge-Inspector')
