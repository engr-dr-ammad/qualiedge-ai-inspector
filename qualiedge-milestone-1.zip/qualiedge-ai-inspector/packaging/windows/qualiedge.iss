#define AppName "QualiEdge AI Inspector"
#define AppVersion "0.1.0"
[Setup]
AppId={{F0C49D29-9D4A-4BC1-9CB4-19F63DCD33AF}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Ammad Aslam
DefaultDirName={localappdata}\Programs\QualiEdge AI Inspector
DefaultGroupName=QualiEdge AI Inspector
PrivilegesRequired=lowest
OutputDir=..\..\dist
OutputBaseFilename=QualiEdge-Inspector-Setup-{#AppVersion}
Compression=lzma
SolidCompression=yes
UninstallDisplayName={#AppName}
[Files]
Source: "..\..\dist\QualiEdge-Inspector\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs
[Icons]
Name: "{group}\QualiEdge AI Inspector"; Filename: "{app}\QualiEdge-Inspector.exe"
Name: "{autodesktop}\QualiEdge AI Inspector"; Filename: "{app}\QualiEdge-Inspector.exe"; Tasks: desktopicon
[Tasks]
Name: desktopicon; Description: "Create desktop shortcut"; Flags: unchecked
[Run]
Filename: "{app}\QualiEdge-Inspector.exe"; Description: "Launch QualiEdge"; Flags: nowait postinstall skipifsilent
