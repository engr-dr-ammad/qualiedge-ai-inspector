# QualiEdge AI Inspector

**Developed by Ammad Aslam**  
Copyright © 2026 Ammad Aslam. All rights reserved.

This repository currently contains **Milestone 1: the native desktop application foundation**.
It does **not** yet perform inspections. The other milestones are planned, not implemented.

## Run locally

Requires Python 3.12.

```bash
python -m venv .venv
# Activate the environment (Windows: .venv\Scripts\activate)
python -m pip install -e '.[dev]'
python -m qualiedge
```

## Test

```bash
ruff check src tests
python -m pytest -q
```

On headless Linux, set `QT_QPA_PLATFORM=offscreen` for GUI tests.

## Windows packaging

On a Windows GitHub Actions runner or Windows development machine:

```powershell
pyinstaller --noconfirm packaging/pyinstaller.spec
& 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe' packaging\windows\qualiedge.iss
```

The Windows workflow is a build starting point; a successful build and clean-VM installation must be verified before release.

## Offline-first design

The current app makes no application-initiated network calls. GitHub Actions and installation of build dependencies need internet access. Future integrations must be opt-in.

## Licence

Original project files are proprietary and not licensed for redistribution. Dependencies have independent licences. See `THIRD_PARTY_LICENSES.md` for preliminary notices; audit exact package versions before release.
