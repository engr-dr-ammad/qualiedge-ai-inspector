# Release checklist

- [ ] CI passes on Windows, Linux and macOS
- [ ] GUI opens on all target systems
- [ ] Windows installer builds successfully
- [ ] Install and uninstall tested on clean Windows VM
- [ ] Dependencies and redistributable licences audited
- [ ] App icon and version metadata added
- [ ] Core inspection features completed and validated
- [ ] No unapproved network traffic
- [ ] User documentation completed
