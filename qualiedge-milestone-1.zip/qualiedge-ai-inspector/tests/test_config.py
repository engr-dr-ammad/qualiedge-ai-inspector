import json
import pytest
from pydantic import ValidationError
from qualiedge.config import Settings, load_settings, save_settings

def test_settings_defaults():
    assert Settings().language == "en"
    assert Settings().theme == "light"

def test_settings_round_trip(tmp_path):
    path = tmp_path / "settings.json"
    save_settings(Settings(language="de", theme="dark"), path)
    assert load_settings(path) == Settings(language="de", theme="dark")
    assert json.loads(path.read_text())["language"] == "de"

def test_invalid_language_rejected():
    with pytest.raises(ValidationError):
        Settings(language="fr")
