from qualiedge.ui.main_window import MainWindow, PAGES

def test_window_navigation(qtbot):
    window = MainWindow()
    qtbot.addWidget(window)
    assert window.navigation.count() == len(PAGES)
    window.navigation.setCurrentRow(2)
    assert window.pages.currentIndex() == 2
    assert "QualiEdge" in window.windowTitle()
