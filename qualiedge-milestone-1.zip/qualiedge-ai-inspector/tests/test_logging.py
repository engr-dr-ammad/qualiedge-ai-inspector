from qualiedge.logging_setup import configure_logging

def test_logging_creates_directory(tmp_path):
    assert configure_logging(tmp_path / "logs").parent.is_dir()
