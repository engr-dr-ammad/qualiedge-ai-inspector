"""Desktop application entrypoint."""
from __future__ import annotations
import logging
import sys
from PySide6.QtWidgets import QApplication
from qualiedge.logging_setup import configure_logging
from qualiedge.ui.main_window import MainWindow

def main() -> int:
    configure_logging()
    logging.getLogger("qualiedge").info("Starting QualiEdge")
    app = QApplication.instance() or QApplication(sys.argv)
    assert isinstance(app, QApplication)
    app.setApplicationName("QualiEdge AI Inspector")
    app.setOrganizationName("Ammad Aslam")
    window = MainWindow()
    window.show()
    return app.exec()
