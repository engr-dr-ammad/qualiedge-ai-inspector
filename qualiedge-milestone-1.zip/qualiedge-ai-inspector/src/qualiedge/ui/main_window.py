"""Milestone 1 desktop shell. Disabled modules are not presented as working."""
from __future__ import annotations
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QListWidget, QMainWindow,
    QMessageBox, QPushButton, QStackedWidget, QVBoxLayout, QWidget)
from qualiedge import __version__

PAGES = ["Dashboard", "Live Inspection", "Recipes", "Create Recipe", "Review Queue",
         "History", "Reports", "Cameras", "Integrations", "Settings", "Diagnostics"]

class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"QualiEdge AI Inspector — {__version__}")
        self.resize(1440, 900)
        self.setMinimumSize(1100, 680)
        self.setObjectName("MainWindow")
        outer = QWidget()
        layout = QHBoxLayout(outer)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(250)
        side_layout = QVBoxLayout(sidebar)
        logo = QLabel("QUALIEDGE")
        logo.setObjectName("Brand")
        side_layout.addWidget(logo)
        side_layout.addWidget(QLabel("AI INSPECTOR"))
        self.navigation = QListWidget()
        self.navigation.addItems(PAGES)
        self.navigation.setObjectName("Navigation")
        side_layout.addWidget(self.navigation)
        about = QPushButton("About QualiEdge")
        about.clicked.connect(self.show_about)
        side_layout.addWidget(about)
        layout.addWidget(sidebar)
        self.pages = QStackedWidget()
        for title in PAGES:
            page = QWidget()
            v = QVBoxLayout(page)
            heading = QLabel(title)
            heading.setObjectName("PageHeading")
            v.addWidget(heading)
            if title == "Dashboard":
                v.addWidget(QLabel("Welcome to QualiEdge AI Inspector"))
                v.addWidget(QLabel("Reference-based inspection for fixed-geometry parts."))
                v.addWidget(QLabel("Validate on your own parts before production use."))
            else:
                v.addWidget(QLabel("Planned feature — not yet implemented."))
            v.addStretch()
            self.pages.addWidget(page)
        self.navigation.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.navigation.setCurrentRow(0)
        layout.addWidget(self.pages, 1)
        self.setCentralWidget(outer)
        self.statusBar().showMessage("Foundation build · No camera connected · Offline")
        self.setStyleSheet("""
            QMainWindow { background: #f4f7fa; }
            #Sidebar { background: #10243a; color: white; }
            #Sidebar QLabel { color: white; padding: 8px; }
            #Brand { font-size: 24px; font-weight: bold; }
            #Navigation { background: #10243a; color: white; border: 0; font-size: 14px; }
            #Navigation::item { padding: 11px; }
            #Navigation::item:selected { background: #1677d2; }
            #PageHeading { color: #10243a; font-size: 28px; font-weight: bold; }
            QPushButton { padding: 10px; }
        """)

    def show_about(self) -> None:
        QMessageBox.about(self, "About QualiEdge", (
            f"QualiEdge AI Inspector v{__version__}\n"
            "Developed by Ammad Aslam\n"
            "Copyright © 2026 Ammad Aslam. All rights reserved.\n\n"
            "Reference-based inspection for fixed-geometry parts. "
            "Validate on your own parts before use in production.\n\n"
            "Foundation milestone: inspection functionality is not yet available."
        ))
