"""QualiEdge AI Inspector — Developed by Ammad Aslam."""
__version__ = "0.1.0"
