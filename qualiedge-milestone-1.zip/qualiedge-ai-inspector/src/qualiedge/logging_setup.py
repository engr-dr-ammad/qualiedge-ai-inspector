import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from qualiedge.config import data_directory

def configure_logging(directory: Path | None = None) -> Path:
    directory = directory or data_directory()
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "qualiedge.log"
    logger = logging.getLogger("qualiedge")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = RotatingFileHandler(path, maxBytes=2_000_000, backupCount=3,
                                      encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        logger.addHandler(handler)
    return path
