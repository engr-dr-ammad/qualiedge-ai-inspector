"""Local settings with validated schema and atomic updates."""
from __future__ import annotations
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from platformdirs import user_data_dir
from pydantic import BaseModel, Field

APP_NAME = "QualiEdge"

class Settings(BaseModel):
    language: str = Field(default="en", pattern="^(en|de)$")
    theme: str = Field(default="light", pattern="^(light|dark)$")
    last_recipe_id: str | None = None

def data_directory() -> Path:
    override = os.environ.get("QUALIEDGE_DATA_DIR")
    return Path(override).expanduser() if override else Path(user_data_dir(APP_NAME, appauthor=False))

def load_settings(path: Path | None = None) -> Settings:
    path = path or data_directory() / "settings.json"
    if not path.exists():
        return Settings()
    return Settings.model_validate_json(path.read_text(encoding="utf-8"))

def save_settings(settings: Settings, path: Path | None = None) -> None:
    path = path or data_directory() / "settings.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_name: str | None = None
    try:
        with NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                 prefix=".settings-", suffix=".tmp", delete=False) as f:
            temp_name = f.name
            json.dump(settings.model_dump(mode="json"), f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name, path)
    finally:
        if temp_name and Path(temp_name).exists():
            Path(temp_name).unlink()
