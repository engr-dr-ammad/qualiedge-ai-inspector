# Architecture decisions

- Python 3.12 + PySide6 for native desktop GUI.
- `src/` layout and hatchling packaging.
- Platformdirs for user-local data directories.
- Pydantic for schema-validated settings.
- Atomic replacement for settings writes.
- One-folder PyInstaller output to simplify debugging and LGPL compliance planning.
- Inno Setup per-user Windows installer; user data is not uninstalled.
