# Architecture (Milestone 1)

`qualiedge.app` owns the Qt lifecycle. `qualiedge.ui` owns presentation.
`qualiedge.config` validates and persists local settings. `qualiedge.logging_setup`
configures rotating logs. Future `engine`, `cameras`, `recipes`, `database` and
`services` packages will have explicit interfaces and no GUI dependency in engine.
