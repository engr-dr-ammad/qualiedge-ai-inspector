# Installation (development build)

Use Python 3.12 and follow the README. End-user installers have not been verified.
A clean Windows VM install test is required before distribution.
