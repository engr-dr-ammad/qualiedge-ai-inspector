# Limitations

This milestone is a desktop shell and does not inspect parts. Future reference-based
inspection will require stable lighting, fixed geometry and validation on customer parts.
